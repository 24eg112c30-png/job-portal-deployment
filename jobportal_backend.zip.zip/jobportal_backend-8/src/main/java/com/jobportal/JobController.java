package com.jobportal;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins = "*")
public class JobController {

    @GetMapping("/api/jobs")
    public List<Map<String, Object>> getJobs() {

        return List.of(
            Map.of(
                "id", 1,
                "title", "Software Developer",
                "company", "TCS",
                "location", "Hyderabad",
                "salary", "4 LPA"
            ),
            Map.of(
                "id", 2,
                "title", "Java Developer",
                "company", "Infosys",
                "location", "Hyderabad",
                "salary", "5 LPA"
            )
        );
    }
}