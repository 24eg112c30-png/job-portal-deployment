package com.jobportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobportalBackend8Application {

	public static void main(String[] args) {
		SpringApplication.run(JobportalBackend8Application.class, args);
	}

}
