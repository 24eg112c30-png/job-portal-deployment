package com.jobportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobportalBackend8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
